#!/bin/sh
set -eu
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
check_dir=$(mktemp -d)
trap 'rm -rf "$check_dir"' EXIT
cd "$project_dir"
python3 tools/check_world_atlas.py
python3 tools/check_stream_collision.py
python3 tools/check_frontend_assets.py
python3 tools/prepare_stream_progress.py --check
python3 tools/test_character_rotations.py
python3 tools/test_atlas_materials.py
cc -Wall -Wextra -Werror -fsanitize=address,undefined src/frontend.c tools/test_frontend.c -o "$check_dir/frontend"
ASAN_OPTIONS=detect_leaks=0 "$check_dir/frontend"
cc -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined src/stream_world.c src/stream_collision_cache.c src/player.c src/surface.c src/collision.c tools/test_stream_world.c -o "$check_dir/world"
ASAN_OPTIONS=detect_leaks=0 "$check_dir/world"
cc -DZERA_STREAM_RELICS -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined src/checkpoint.c src/relics.c src/player.c src/stream_world.c src/stream_collision_cache.c src/surface.c src/collision.c tools/test_stream_progress.c -o "$check_dir/progress"
ASAN_OPTIONS=detect_leaks=0 "$check_dir/progress"

python3 tools/check_frontend_ui.py
python3 tools/check_model_guard.py
python3 tools/check_stream_collision.py --area previews/cosmic
cc -DZERA_CAMPAIGN_ENTRY -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined src/stream_world.c src/stream_collision_cache.c src/player.c src/surface.c src/collision.c tools/test_cosmic_world.c -o "$check_dir/cosmic"
ASAN_OPTIONS=detect_leaks=0 "$check_dir/cosmic"
cc -DZERA_CAMPAIGN_ENTRY -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined src/frontend.c tools/test_campaign_frontend.c -o "$check_dir/campaign_frontend"
ASAN_OPTIONS=detect_leaks=0 "$check_dir/campaign_frontend"

python3 tools/check_levium.py
cc -DZERA_CAMPAIGN_ENTRY -Wall -Wextra -Werror -Wno-misleading-indentation -fsanitize=address,undefined src/dialogue.c src/player.c src/stream_world.c src/stream_collision_cache.c src/surface.c src/collision.c tools/test_levium.c -o "$check_dir/levium"
ASAN_OPTIONS=detect_leaks=0 "$check_dir/levium"
